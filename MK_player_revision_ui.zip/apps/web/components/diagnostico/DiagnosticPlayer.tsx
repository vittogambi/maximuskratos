'use client';

import { useRouter } from 'next/navigation';
import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import { useAuthSession } from '@/components/auth-session-provider';
import {
  apiDiagnosticState,
  apiDiagnosticSubmitResponse,
  type DiagnosticState,
} from '@/lib/api';
import { getAccessToken } from '@/lib/auth-storage';
import { AppIcon } from '@/components/app-icon';
import { ReviewVersionNote } from '@/components/app-shell/ReviewVersionNote';
import {
  buildInitialSelection,
  continueHint,
  isSelectionValid,
  QuestionCard,
  selectionToPayload,
} from './QuestionCard';
import { moduleIntroIcon } from './module-intro-icon';
import { ProgressRail } from './ProgressRail';
import { PlayerStage } from './PlayerStage';
import { DiagnosticBlackout } from './DiagnosticBlackout';
import { stashOutroBootstrap } from '@/lib/diagnostic-outro-bootstrap';
import {
  introIconItem,
  introStaggerContainer,
  introStaggerItem,
  moduleIntroVariants,
  questionScreenVariants,
} from './diagnostic-motion';

type PlayerStatus = 'loading' | 'module_intro' | 'question' | 'error';

type HistoryEntry = {
  state: DiagnosticState;
  selection: ReturnType<typeof buildInitialSelection>;
};

export function DiagnosticPlayer() {
  const router = useRouter();
  const { status } = useAuthSession();
  const reduced = useReducedMotion();
  const [playerStatus, setPlayerStatus] = useState<PlayerStatus>('loading');
  const [state, setState] = useState<DiagnosticState | null>(null);
  const [selection, setSelection] = useState<ReturnType<typeof buildInitialSelection> | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [blackout, setBlackout] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const shownAtRef = useRef<number>(Date.now());
  const historyRef = useRef<HistoryEntry[]>([]);
  const stateRef = useRef(state);
  const scrollRef = useRef<HTMLDivElement>(null);
  stateRef.current = state;

  useEffect(() => {
    if (status === 'guest') {
      router.replace('/login');
      return;
    }

    const token = getAccessToken();
    if (status === 'loading' && !token) return;
    if (!token) {
      router.replace('/login');
      return;
    }

    let cancelled = false;

    apiDiagnosticState(token)
      .then((s) => {
        if (cancelled) return;
        if (s.sessionState.showWelcomeScreen) {
          router.replace('/diagnostico/bienvenida');
          return;
        }
        applyState(s);
      })
      .catch(() => {
        if (cancelled) return;
        setError('No se pudo cargar el cuestionario.');
        setPlayerStatus('error');
      });

    return () => {
      cancelled = true;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  function applyState(s: DiagnosticState, skipIntro = false, pushHistory = false) {
    if (s.sessionState.showWelcomeScreen) {
      router.replace('/diagnostico/bienvenida');
      return;
    }
    if (pushHistory && state?.nextStep.type === 'question' && selection) {
      historyRef.current = [...historyRef.current, { state, selection }];
    }
    setState(s);
    if (s.nextStep.type === 'question') {
      if (s.sessionState.isModuleStart && !skipIntro) {
        setPlayerStatus('module_intro');
      } else {
        setSelection(buildInitialSelection(s.nextStep.data));
        setPlayerStatus('question');
        shownAtRef.current = Date.now();
      }
    } else if (s.nextStep.type === 'module_outro') {
      stashOutroBootstrap(s);
      router.replace(`/diagnostico/outro/${s.nextStep.data.moduleSlug}`);
    } else if (s.nextStep.type === 'diagnostic_complete') {
      router.replace('/diagnostico/resultado');
    }
  }

  function navigateToOutro(next: DiagnosticState) {
    if (next.nextStep.type !== 'module_outro') return;
    stashOutroBootstrap(next);
    if (reduced) {
      router.replace(`/diagnostico/outro/${next.nextStep.data.moduleSlug}`);
      return;
    }
    setBlackout(true);
    const slug = next.nextStep.data.moduleSlug;
    window.setTimeout(() => {
      router.replace(`/diagnostico/outro/${slug}`);
    }, 380);
  }

  function handleGoBack() {
    const prev = historyRef.current.at(-1);
    if (!prev) return;
    historyRef.current = historyRef.current.slice(0, -1);
    setState(prev.state);
    setSelection(prev.selection);
    setPlayerStatus('question');
    shownAtRef.current = Date.now();
  }

  async function handleSubmit() {
    if (!state || !selection || isSubmitting) return;
    if (state.nextStep.type !== 'question') return;
    if (!isSelectionValid(state.nextStep.data, selection)) return;

    const token = getAccessToken();
    if (!token) return;

    const submittedId = state.nextStep.data.id;
    setIsSubmitting(true);
    setError(null);

    try {
      const next = await apiDiagnosticSubmitResponse(token, {
        questionId: submittedId,
        ...selectionToPayload(selection),
        expectedRevision: state.nextStep.data.answerRevision ?? 0,
        latencyMs: Date.now() - shownAtRef.current,
      });

      const current = stateRef.current;
      const stillHere = current?.nextStep.type === 'question' && current.nextStep.data.id === submittedId;
      if (!stillHere) return;

      if (next.nextStep.type === 'module_outro') {
        navigateToOutro(next);
        return;
      }

      applyState(next, false, true);
    } catch (err) {
      const status = (err as { status?: number }).status;
      const current = stateRef.current;
      const stillHere = current?.nextStep.type === 'question' && current.nextStep.data.id === submittedId;
      if (!stillHere) {
        // A late failure belongs to the earlier question. It must not replace the one on screen.
        setError('No se pudo guardar la respuesta anterior. Vuelve a ella para reintentar.');
        return;
      }
      setError(status === 409
        ? 'Otra sesión escribió después. Recarga el cuestionario antes de guardar.'
        : 'No se pudo guardar. El texto sigue aquí. Puedes reintentar.');
    } finally {
      setIsSubmitting(false);
    }
  }

  async function handleSaveAndExit() {
    if (isSubmitting) return;
    const question = state?.nextStep.type === 'question' ? state.nextStep.data : null;
    const hasPendingAnswer =
      playerStatus === 'question' &&
      question !== null &&
      selection !== null &&
      isSelectionValid(question, selection);

    if (!hasPendingAnswer) {
      router.push('/panel');
      return;
    }

    setIsSubmitting(true);
    setIsExiting(true);
    setError(null);
    try {
      const token = getAccessToken();
      if (!token) throw new Error('missing_token');
      await apiDiagnosticSubmitResponse(token, {
        questionId: question.id,
        ...selectionToPayload(selection),
        expectedRevision: question.answerRevision ?? 0,
        latencyMs: Date.now() - shownAtRef.current,
      });
      router.push('/panel');
    } catch {
      setError('No pudimos guardar tu respuesta. Revisa tu conexión e intenta de nuevo.');
      setIsExiting(false);
      setIsSubmitting(false);
    }
  }

  function handleStartModule() {
    if (!state || state.nextStep.type !== 'question') return;
    setSelection(buildInitialSelection(state.nextStep.data));
    setPlayerStatus('question');
    shownAtRef.current = Date.now();
  }

  const currentQuestion =
    state?.nextStep.type === 'question' ? state.nextStep.data : null;
  const isValid =
    currentQuestion && selection ? isSelectionValid(currentQuestion, selection) : false;
  const ss = state?.sessionState;
  const canGoBack = historyRef.current.length > 0;
  const introKey = ss?.currentModuleSlug ?? 'intro';

  useEffect(() => {
    if (playerStatus !== 'question' || !currentQuestion) return;
    const scroller = scrollRef.current;
    if (scroller && typeof scroller.scrollTo === 'function') scroller.scrollTo({ top: 0 });
    document.getElementById('dk-question-title')?.focus();
  }, [playerStatus, currentQuestion?.id]);

  if (playerStatus === 'loading') {
    return (
      <main className="dk-player-shell">
        <div className="dk-player-center">
          <div className="auth-loading"><span className="auth-spinner" aria-hidden /></div>
        </div>
      </main>
    );
  }

  if (playerStatus === 'error' || !state || !ss) {
    return (
      <PlayerStage
        header={null}
        primary={{ label: 'Volver al inicio', onClick: () => router.push('/diagnostico') }}
      >
        <p className="dk-player-error" role="alert">{error ?? 'Ocurrió un error inesperado.'}</p>
      </PlayerStage>
    );
  }

  const onIntro = playerStatus === 'module_intro';
  const introStep =
    onIntro && ss.currentModuleOrder != null && ss.totalModules > 0
      ? `Módulo ${ss.currentModuleOrder} de ${ss.totalModules}`
      : null;
  const introMinutes =
    onIntro && ss.currentModuleEstimatedMinutes != null && ss.currentModuleEstimatedMinutes > 0
      ? ss.currentModuleEstimatedMinutes === 1
        ? '1 minuto'
        : `${ss.currentModuleEstimatedMinutes} minutos`
      : null;
  const introIcon = onIntro ? moduleIntroIcon(ss.currentModuleSlug, ss.currentModuleIcon) : null;

  const asking = playerStatus === 'question' && currentQuestion != null && selection != null;
  const primaryLabel = onIntro
    ? 'Comenzar'
    : isSubmitting && !isExiting
      ? 'Guardando…'
      : 'Continuar';

  return (
    <>
      <DiagnosticBlackout visible={blackout} />
      <PlayerStage
        bodyRef={scrollRef}
        hint={asking && !isValid ? continueHint(currentQuestion) : null}
        back={asking && canGoBack ? { label: 'Anterior', onClick: handleGoBack, disabled: isExiting } : null}
        primary={{
          label: primaryLabel,
          onClick: onIntro ? handleStartModule : handleSubmit,
          disabled: onIntro ? false : !isValid || isSubmitting,
        }}
        header={(
          <ProgressRail
            pct={ss.completionPct}
            questionIndex={playerStatus === 'question' ? ss.currentQuestionIndex : undefined}
            questionTotal={playerStatus === 'question' ? ss.moduleQuestionCount : undefined}
            moduleTitle={introStep ?? ss.currentModuleTitle}
            contextLabel="Auditoría inicial"
            aside={introMinutes}
            exitLabel={playerStatus === 'question' ? (isExiting ? 'Guardando…' : 'Guardar y salir') : null}
            exitDisabled={isSubmitting}
            onExit={playerStatus === 'question' ? handleSaveAndExit : undefined}
          />
        )}
      >
        <AnimatePresence mode="wait">
          {playerStatus === 'module_intro' && (
            <motion.div
              key={`intro-${introKey}`}
              className="dk-intro-body"
              variants={reduced ? undefined : moduleIntroVariants}
              initial={reduced ? false : 'initial'}
              animate={reduced ? undefined : 'animate'}
              exit={reduced ? undefined : 'exit'}
            >
              <motion.div
                variants={reduced ? undefined : introStaggerContainer}
                initial={reduced ? false : 'hidden'}
                animate={reduced ? undefined : 'show'}
              >
                {!introStep && ss.currentModuleOrder != null && ss.totalModules > 0 && (
                  <motion.p className="dk-intro-meta" variants={reduced ? undefined : introStaggerItem}>
                    Módulo {ss.currentModuleOrder} de {ss.totalModules}
                  </motion.p>
                )}
                {introIcon ? (
                  <motion.div
                    className="dk-module-icon-wrap"
                    variants={reduced ? undefined : introIconItem}
                  >
                    <AppIcon name={introIcon} size={28} />
                  </motion.div>
                ) : null}
                <motion.h1 className="dk-intro-title" variants={reduced ? undefined : introStaggerItem}>
                  {ss.currentModuleTitle}
                </motion.h1>
                {ss.currentModuleIntro ? (
                  <motion.p className="dk-intro-text" variants={reduced ? undefined : introStaggerItem}>
                    {ss.currentModuleIntro}
                  </motion.p>
                ) : null}
                {!introMinutes && ss.currentModuleEstimatedMinutes != null && ss.currentModuleEstimatedMinutes > 0 && (
                  <motion.p className="dk-intro-duration" variants={reduced ? undefined : introStaggerItem}>
                    {ss.currentModuleEstimatedMinutes === 1
                      ? '1 minuto'
                      : `${ss.currentModuleEstimatedMinutes} minutos`}
                  </motion.p>
                )}
                <ReviewVersionNote />
              </motion.div>
            </motion.div>
          )}

          {asking && (
            <motion.div
              key={currentQuestion.id}
              variants={reduced ? undefined : questionScreenVariants}
              initial={reduced ? false : 'initial'}
              animate={reduced ? undefined : 'animate'}
              exit={reduced ? undefined : 'exit'}
            >
              <QuestionCard
                question={currentQuestion}
                selection={selection}
                onChange={setSelection}
              />
            </motion.div>
          )}
        </AnimatePresence>
        {error ? <p className="dk-player-error" role="alert">{error}</p> : null}
      </PlayerStage>
    </>
  );
}
