'use client';

import { useEffect, useRef, useState } from 'react';

type Props = {
  pct: number;
  questionIndex?: number | null;
  questionTotal?: number | null;
  moduleTitle?: string | null;
  /** Short name of this pass, shown with the exit action. */
  contextLabel?: string | null;
  /** default = in-question; outro = module just finished */
  variant?: 'default' | 'outro';
  exitLabel?: string | null;
  exitDisabled?: boolean;
  onExit?: () => void;
  /** Replaces the percent on screens that already state their own context, such as a module intro. */
  aside?: string | null;
};

export function ProgressRail({
  pct,
  questionIndex,
  questionTotal,
  moduleTitle,
  contextLabel,
  variant = 'default',
  exitLabel,
  exitDisabled,
  onExit,
  aside,
}: Props) {
  const displayPct = Math.min(100, Math.max(0, Math.round(pct)));
  const isOutro = variant === 'outro';
  const hasCounter = questionIndex != null && questionTotal != null && questionTotal > 0;
  const prevPctRef = useRef(displayPct);
  const [pulse, setPulse] = useState(false);

  useEffect(() => {
    if (displayPct > prevPctRef.current) {
      setPulse(true);
      prevPctRef.current = displayPct;
      const timer = window.setTimeout(() => setPulse(false), 650);
      return () => window.clearTimeout(timer);
    }
    prevPctRef.current = displayPct;
  }, [displayPct]);

  const statusLabel = aside
    ? aside
    : isOutro
      ? 'Completo'
      : hasCounter
        ? `Pregunta ${questionIndex} de ${questionTotal}`
        : `${displayPct}%`;
  const showPercent = Boolean(aside || isOutro || hasCounter);

  return (
    <div
      className={`dk-progress-rail${isOutro ? ' dk-progress-rail--complete' : ''}`}
      role="progressbar"
      aria-valuenow={displayPct}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={`Diagnóstico ${displayPct}% completado`}
    >
      {(contextLabel || (exitLabel && onExit)) && (
        <div className="dk-rail-top">
          {contextLabel ? <p className="dk-rail-context">{contextLabel}</p> : <span />}
          {exitLabel && onExit ? (
            <button
              type="button"
              className="dk-exit-link"
              onClick={onExit}
              disabled={exitDisabled}
            >
              {exitLabel}
            </button>
          ) : null}
        </div>
      )}
      <div className="dk-rail-info">
        <span className="dk-rail-module-name">
          {moduleTitle ?? 'Diagnóstico'}
        </span>
        <span className={`dk-rail-counter${isOutro ? ' dk-rail-counter--done' : ''}`}>
          {statusLabel}
        </span>
      </div>

      <div className="dk-rail-track">
        <div
          className={`dk-rail-fill${pulse ? ' dk-rail-fill--pulse' : ''}`}
          style={{ width: `${displayPct}%` }}
        />
      </div>
      {showPercent ? <p className="dk-rail-pct">{displayPct}%</p> : null}
    </div>
  );
}
