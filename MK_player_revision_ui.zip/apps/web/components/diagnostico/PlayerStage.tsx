'use client';

import type { ReactNode, Ref } from 'react';

type Action = {
  label: string;
  onClick: () => void;
  disabled?: boolean;
};

type Props = {
  header: ReactNode;
  children: ReactNode;
  primary: Action;
  back?: Action | null;
  /** Shown when the primary action is blocked. The slot keeps its height either way. */
  hint?: string | null;
  bodyRef?: Ref<HTMLDivElement>;
};

/** Header, scrolling body, stable bottom bar. Screens do not place their own button. */
export function PlayerStage({ header, children, primary, back, hint, bodyRef }: Props) {
  return (
    <main className="dk-stage">
      <div className="dk-stage__header">{header}</div>
      <div className="dk-stage__body" ref={bodyRef}>
        {children}
      </div>
      <div className="dk-stage__nav">
        <p className="dk-stage__hint" id="dk-continue-hint">{hint ?? ''}</p>
        <div className="dk-stage__nav-row">
          {back ? (
            <button
              type="button"
              className="dk-back-btn"
              onClick={back.onClick}
              disabled={back.disabled}
            >
              {back.label}
            </button>
          ) : null}
          <button
            type="button"
            className="ag-btn-cta"
            onClick={primary.onClick}
            disabled={primary.disabled}
            aria-describedby={hint ? 'dk-continue-hint' : undefined}
          >
            {primary.label}
          </button>
        </div>
      </div>
    </main>
  );
}
