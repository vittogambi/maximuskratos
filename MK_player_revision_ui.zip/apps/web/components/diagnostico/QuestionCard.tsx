'use client';

import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import type { LineField, MeasureField, QuestionDto } from '@/lib/api';
import { ArchetypeChoices, isArchetypeChoice } from './options/ArchetypeChoices';
import { optionListItem, reasonBoxVariants } from './diagnostic-motion';
import { FreeTextOption } from './options/FreeTextOption';
import { MultiChoiceOptions } from './options/MultiChoiceOptions';
import { ScaleOptions } from './options/ScaleOptions';
import { scalePromptFor } from '@/lib/scale-prompts';
import { SingleChoiceOptions } from './options/SingleChoiceOptions';

type SelectionState =
  | { type: 'single'; selected: string | null }
  | { type: 'multi'; selected: string[] }
  | { type: 'scale'; selected: string | null; selectedOrder: number | null; reason: string }
  | { type: 'text'; value: string }
  | { type: 'ranking'; order: string[] }
  | { type: 'exception'; kind: 'UNKNOWN' | 'NOT_APPLICABLE' | 'DECLINED' };

type Props = {
  question: QuestionDto;
  selection: SelectionState;
  onChange: (next: SelectionState) => void;
};

export function QuestionCard({ question, selection, onChange }: Props) {
  const reduced = useReducedMotion();
  const scalePrompt = question.type === 'SCALE_1_5' ? scalePromptFor(question.sourceRef) : null;
  const questionTitle = scalePrompt?.stem ?? question.textEs;

  const showReasonBox =
    question.type === 'SCALE_1_5' &&
    question.reasonThreshold != null &&
    question.reasonPromptEs != null &&
    selection.type === 'scale' &&
    selection.selectedOrder != null &&
    selection.selectedOrder <= question.reasonThreshold;

  return (
    <div className="dk-question">
      <div className="dk-question__lead">
        {question.heading ? <p className="dk-question-context">{question.heading}</p> : null}
        <h2 id="dk-question-title" tabIndex={-1} className="dk-question-text">{questionTitle}</h2>
        {question.type === 'MULTI_CHOICE' &&
          question.maxSelections != null &&
          selection.type === 'multi' && (
            <p
              className="dk-multi-counter"
              aria-label={`${selection.selected.length} de ${question.maxSelections} seleccionadas`}
            >
              {selection.selected.length} de {question.maxSelections}
            </p>
          )}
      </div>

      <div className="dk-question__answers">
        {question.type === 'SINGLE_CHOICE' && selection.type === 'single' && isArchetypeChoice(question.options) && (
          <ArchetypeChoices
            options={question.options}
            selected={selection.selected}
            onSelect={(id) => onChange({ type: 'single', selected: id })}
          />
        )}

        {question.type === 'SINGLE_CHOICE' && selection.type === 'single' && !isArchetypeChoice(question.options) && (
          <SingleChoiceOptions
            options={question.options}
            selected={selection.selected}
            onSelect={(id) => onChange({ type: 'single', selected: id })}
          />
        )}

        {question.type === 'MULTI_CHOICE' && selection.type === 'multi' && (
          <MultiChoiceOptions
            options={question.options}
            selected={selection.selected}
            maxSelections={question.maxSelections}
            onToggle={(id) => {
              const current = selection.selected;
              const next = current.includes(id)
                ? current.filter((s) => s !== id)
                : [...current, id];
              onChange({ type: 'multi', selected: next });
            }}
          />
        )}

        {question.type === 'SCALE_1_5' && selection.type === 'scale' && (
          <>
            <ScaleOptions
              options={question.options}
              selected={selection.selected}
              scaleType={question.scaleType}
              prompt={scalePrompt}
              onSelect={(id) => {
                const opt = question.options.find((o) => o.id === id);
                onChange({
                  type: 'scale',
                  selected: id,
                  selectedOrder: opt?.order ?? null,
                  reason: selection.reason,
                });
              }}
            />
            <AnimatePresence initial={false}>
              {showReasonBox && (
                <motion.div
                  key="reason"
                  className="dk-reason-box"
                  variants={reduced ? undefined : reasonBoxVariants}
                  initial={reduced ? false : 'hidden'}
                  animate={reduced ? undefined : 'visible'}
                  exit={reduced ? undefined : 'hidden'}
                  style={{ overflow: 'hidden' }}
                >
                  <label className="dk-reason-label" htmlFor="dk-reason-input">
                    {question.reasonPromptEs}
                  </label>
                  <textarea
                    id="dk-reason-input"
                    className="dk-reason-textarea"
                    value={selection.reason}
                    onChange={(e) =>
                      onChange({
                        ...selection,
                        reason: e.target.value,
                      })
                    }
                    maxLength={500}
                    rows={3}
                    placeholder="Escribe tu respuesta, si quieres."
                  />
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && question.capture?.kind === 'measures' && (
          <MeasuresFields
            fields={question.capture.fields}
            value={selection.value}
            onChange={(value) => onChange({ type: 'text', value })}
          />
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && question.capture?.kind === 'lines' && (
          <LinesFields
            fields={question.capture.fields}
            value={selection.value}
            onChange={(value) => onChange({ type: 'text', value })}
          />
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && question.capture?.kind === 'hours' && (
          <HoursField
            min={question.capture.min}
            max={question.capture.max}
            value={selection.value}
            onChange={(value) => onChange({ type: 'text', value })}
          />
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && question.capture?.kind === 'number' && (
          <NumberField
            unit={question.capture.unit}
            min={question.capture.min}
            max={question.capture.max}
            value={selection.value}
            onChange={(value) => onChange({ type: 'text', value })}
          />
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && question.capture?.kind === 'activity' && (
          <ActivityField
            ambits={question.capture.ambits ?? []}
            value={selection.value}
            onChange={(value) => onChange({ type: 'text', value })}
          />
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && question.capture?.kind === 'ikigai' && (
          <IkigaiField
            others={question.capture.others}
            value={selection.value}
            onChange={(value) => onChange({ type: 'text', value })}
          />
        )}

        {question.type === 'FREE_TEXT' && selection.type === 'text' && !question.capture && (
          <motion.div
            variants={reduced ? undefined : optionListItem}
            initial={reduced ? false : 'hidden'}
            animate={reduced ? undefined : 'show'}
          >
            <FreeTextOption
              value={selection.value}
              onChange={(v) => onChange({ type: 'text', value: v })}
            />
          </motion.div>
        )}

        {selection.type !== 'exception' && (question.allowedExceptions?.length ?? 0) > 0 && (
          <details className="dk-exceptions">
            <summary>Si no puedes responderla ahora</summary>
            <div className="dk-exceptions__row">
              {question.allowedExceptions?.filter((kind) => kind !== 'PENDING').map((kind) => (
                <button
                  key={kind}
                  type="button"
                  className="dk-exception"
                  onClick={() => onChange({ type: 'exception', kind: kind as 'UNKNOWN' | 'NOT_APPLICABLE' | 'DECLINED' })}
                >
                  {EXCEPTION_LABELS[kind] ?? kind}
                </button>
              ))}
            </div>
          </details>
        )}
        {selection.type === 'exception' && (
          <div className="dk-exception-chosen" role="status">
            <p>Excepción elegida: {EXCEPTION_LABELS[selection.kind]}.</p>
            <button type="button" className="dk-exception" onClick={() => onChange(buildInitialSelection(question))}>
              Responder con un dato
            </button>
          </div>
        )}

        {question.type === 'RANKING' && (
          <motion.p
            className="font-body-sm"
            style={{ color: 'var(--color-text-muted)' }}
            variants={reduced ? undefined : optionListItem}
            initial={reduced ? false : 'hidden'}
            animate={reduced ? undefined : 'show'}
          >
            (Ranking: disponible en M1)
          </motion.p>
        )}
      </div>
    </div>
  );
}

/** Build initial selection state from question type */
export function buildInitialSelection(question: QuestionDto): SelectionState {
  switch (question.type) {
    case 'SINGLE_CHOICE':
      return { type: 'single', selected: null };
    case 'MULTI_CHOICE':
      return { type: 'multi', selected: [] };
    case 'SCALE_1_5':
      return { type: 'scale', selected: null, selectedOrder: null, reason: '' };
    case 'FREE_TEXT':
      return { type: 'text', value: '' };
    case 'RANKING':
      return { type: 'ranking', order: question.options.map((o) => o.id) };
  }
}

function readMeasures(value: string): Record<string, string> {
  if (!value) return {};
  try {
    const parsed = JSON.parse(value) as unknown;
    if (parsed && typeof parsed === 'object') return parsed as Record<string, string>;
  } catch {
    return {};
  }
  return {};
}

function textAnswerReady(question: QuestionDto, value: string): boolean {
  if (question.capture?.kind === 'number') {
    if (value === '') return false;
    const amount = Number(value);
    return Number.isFinite(amount) && amount >= question.capture.min && amount <= question.capture.max;
  }
  if (question.capture?.kind === 'activity') {
    try {
      const parsed = JSON.parse(value) as { ambit?: string; option?: string; answer?: string };
      const match = question.capture.ambits?.find((item) => item.label === parsed.ambit);
      return Boolean(parsed.answer?.trim() && match?.options.includes(parsed.option ?? ''));
    } catch {
      return false;
    }
  }
  if (question.capture?.kind === 'ikigai') {
    try {
      const parsed = JSON.parse(value) as { activity?: string; also?: string[] };
      return Boolean(parsed.activity?.trim()) && Array.isArray(parsed.also);
    } catch {
      return false;
    }
  }
  if (question.capture?.kind === 'hours') {
    if (value === '') return false;
    const hours = Number(value);
    return Number.isInteger(hours) && hours >= question.capture.min && hours <= question.capture.max;
  }
  if (question.capture?.kind === 'lines') {
    const data = readMeasures(value);
    return question.capture.fields.every((field) => (data[field.key] ?? '').trim().length > 0);
  }
  if (question.capture?.kind === 'measures') {
    const data = readMeasures(value);
    return question.capture.fields.every((field) => {
      if (!data[field.key]) return false;
      const amount = Number(data[field.key]);
      return Number.isFinite(amount) && amount >= field.min && amount <= field.max;
    });
  }
  return value.trim().length > 0;
}

function MeasuresFields({
  fields,
  value,
  onChange,
}: {
  fields: MeasureField[];
  value: string;
  onChange: (next: string) => void;
}) {
  const data = readMeasures(value);
  return (
    <div className="dk-measures">
      {fields.map((field) => (
        <label key={field.key} className="dk-measure">
          <span className="dk-measure__label">{field.label}</span>
          <input
            className="dk-measure__input"
            inputMode="numeric"
            type="number"
            min={field.min}
            max={field.max}
            value={data[field.key] ?? ''}
            aria-label={field.label}
            onChange={(event) =>
              onChange(JSON.stringify({ ...data, [field.key]: event.target.value }))
            }
          />
          <span className="dk-measure__unit">{field.unit}</span>
        </label>
      ))}
    </div>
  );
}

function LinesFields({
  fields,
  value,
  onChange,
}: {
  fields: LineField[];
  value: string;
  onChange: (next: string) => void;
}) {
  const data = readMeasures(value);
  return (
    <div className="dk-lines">
      {fields.map((field) => (
        <label key={field.key} className="dk-line">
          <span className="dk-line__label">{field.label}</span>
          <textarea
            className="dk-line__input"
            rows={2}
            value={data[field.key] ?? ''}
            aria-label={field.label}
            onChange={(event) =>
              onChange(JSON.stringify({ ...data, [field.key]: event.target.value }))
            }
          />
        </label>
      ))}
    </div>
  );
}

function HoursField({
  min,
  max,
  value,
  onChange,
}: {
  min: number;
  max: number;
  value: string;
  onChange: (next: string) => void;
}) {
  const chosen = value === '' ? null : Number(value);
  const label = chosen == null ? 'Desliza hasta las horas' : chosen === 1 ? '1 hora' : `${chosen} horas`;
  return (
    <div className="dk-hours">
      <p className="dk-hours__value">{label}</p>
      <input
        className="dk-hours__range"
        type="range"
        min={min}
        max={max}
        step={1}
        value={chosen ?? min}
        aria-valuemin={min}
        aria-valuemax={max}
        aria-valuenow={chosen ?? undefined}
        aria-valuetext={label}
        onPointerDown={(event) => {
          if (value === '') onChange(event.currentTarget.value);
        }}
        onChange={(event) => onChange(event.target.value)}
      />
      <div className="dk-hours__ends" aria-hidden>
        <span>{min}</span>
        <span>{max}</span>
      </div>
    </div>
  );
}

/** Check if selection is valid to submit */
const EXCEPTION_LABELS: Record<string, string> = {
  UNKNOWN: 'No lo sé',
  NOT_APPLICABLE: 'No aplica',
  DECLINED: 'Prefiero no responder',
};

export function isSelectionValid(q: QuestionDto, sel: SelectionState): boolean {
  if (sel.type === 'exception') return true;
  if (sel.type === 'single') return sel.selected !== null;
  if (sel.type === 'scale') return sel.selected !== null;
  if (sel.type === 'multi') return sel.selected.length > 0;
  if (sel.type === 'text') return textAnswerReady(q, sel.value);
  if (sel.type === 'ranking') return sel.order.length > 0;
  return false;
}

/** Text shown next to a disabled Continuar: what is still missing. */
export function continueHint(q: QuestionDto): string {
  switch (q.type) {
    case 'MULTI_CHOICE':
      return 'Elige al menos una opción para continuar.';
    case 'FREE_TEXT':
      if (q.capture?.kind === 'measures') return 'Completa edad, altura y peso para continuar.';
      if (q.capture?.kind === 'lines') return 'Completa cada casilla para continuar.';
      if (q.capture?.kind === 'hours') return 'Indica las horas para continuar.';
      if (q.capture?.kind === 'number') return `Indica el número en ${q.capture.unit}, o elige una excepción.`;
      if (q.capture?.kind === 'activity') return 'Elige ámbito, desarrollo de idea y escribe tu respuesta. Si no tienes esta actividad, marca una excepción.';
      if (q.capture?.kind === 'ikigai') return 'Escribe la actividad. El cruce con otros campos es opcional.';
      return 'Escribe tu respuesta para continuar.';
    case 'RANKING':
      return 'Ordena las opciones para continuar.';
    default:
      return 'Elige una opción para continuar.';
  }
}

/** Extract payload for API from selection */
export function selectionToPayload(sel: SelectionState): {
  selectedOptionIds?: string[];
  freeText?: string;
  rankingOrder?: string[];
  exceptionKind?: 'UNKNOWN' | 'NOT_APPLICABLE' | 'DECLINED';
} {
  if (sel.type === 'single' && sel.selected) {
    return { selectedOptionIds: [sel.selected] };
  }
  if (sel.type === 'scale' && sel.selected) {
    const payload: { selectedOptionIds: string[]; freeText?: string } = {
      selectedOptionIds: [sel.selected],
    };
    if (sel.reason.trim()) {
      payload.freeText = sel.reason.trim();
    }
    return payload;
  }
  if (sel.type === 'multi') {
    return { selectedOptionIds: sel.selected };
  }
  if (sel.type === 'text') {
    return { freeText: sel.value.trim() };
  }
  if (sel.type === 'ranking') {
    return { rankingOrder: sel.order };
  }
  if (sel.type === 'exception') {
    return { exceptionKind: sel.kind, selectedOptionIds: [], freeText: undefined };
  }
  return {};
}

function NumberField({
  unit,
  min,
  max,
  value,
  onChange,
}: {
  unit: string;
  min: number;
  max: number;
  value: string;
  onChange: (next: string) => void;
}) {
  return (
    <label className="dk-measure">
      <span className="dk-measure__label">{unit}</span>
      <input
        className="dk-measure__input"
        inputMode="decimal"
        type="number"
        min={min}
        max={max}
        value={value}
        aria-label={unit}
        onChange={(event) => onChange(event.target.value)}
      />
    </label>
  );
}

function ActivityField({
  ambits,
  value,
  onChange,
}: {
  ambits: { label: string; options: string[] }[];
  value: string;
  onChange: (next: string) => void;
}) {
  let ambit = '';
  let option = '';
  let answer = '';
  try {
    const parsed = JSON.parse(value) as { ambit?: string; option?: string; answer?: string };
    ambit = parsed.ambit ?? '';
    option = parsed.option ?? '';
    answer = parsed.answer ?? '';
  } catch {
    ambit = '';
  }
  const choices = ambits.find((item) => item.label === ambit)?.options ?? [];
  const review = Boolean(ambit && answer.trim() && !option);
  function write(next: { ambit: string; option: string; answer: string }) {
    onChange(JSON.stringify(next));
  }
  return (
    <div className="dk-lines">
      <label className="dk-line">
        <span className="dk-line__label">Ámbito</span>
        <select
          className="dk-line__input"
          value={ambit}
          aria-label="Ámbito"
          onChange={(event) => write({ ambit: event.target.value, option: '', answer })}
        >
          <option value="">Elige un ámbito</option>
          {ambits.map((item) => <option key={item.label} value={item.label}>{item.label}</option>)}
        </select>
      </label>
      <label className="dk-line">
        <span className="dk-line__label">Desarrollo de idea</span>
        <select
          className="dk-line__input"
          value={option}
          aria-label="Desarrollo de idea"
          disabled={!ambit}
          onChange={(event) => write({ ambit, option: event.target.value, answer })}
        >
          <option value="">Elige una opción</option>
          {choices.map((item) => <option key={item} value={item}>{item}</option>)}
        </select>
      </label>
      {review ? <p role="status">Revisa el desarrollo de idea. Tu respuesta específica sigue escrita.</p> : null}
      <label className="dk-line">
        <span className="dk-line__label">Respuesta específica</span>
        <textarea
          className="dk-line__input"
          rows={3}
          value={answer}
          aria-label="Respuesta específica"
          onChange={(event) => write({ ambit, option, answer: event.target.value })}
        />
      </label>
    </div>
  );
}

function IkigaiField({
  others,
  value,
  onChange,
}: {
  others: string[];
  value: string;
  onChange: (next: string) => void;
}) {
  let activity = '';
  let also: string[] = [];
  try {
    const parsed = JSON.parse(value) as { activity?: string; also?: string[] };
    activity = parsed.activity ?? '';
    also = parsed.also ?? [];
  } catch {
    activity = '';
  }
  function write(nextActivity: string, nextAlso: string[]) {
    onChange(JSON.stringify({ activity: nextActivity, also: nextAlso }));
  }
  return (
    <div className="dk-lines">
      <label className="dk-line">
        <span className="dk-line__label">Actividad</span>
        <textarea className="dk-line__input" rows={2} value={activity} aria-label="Actividad" onChange={(event) => write(event.target.value, also)} />
      </label>
      <p>También la reconozco en</p>
      {others.map((lens) => (
        <label key={lens} className="dk-measure">
          <input
            type="checkbox"
            checked={also.includes(lens)}
            onChange={(event) => write(activity, event.target.checked ? [...also, lens] : also.filter((item) => item !== lens))}
          />
          {lens}
        </label>
      ))}
    </div>
  );
}
