'use client';

import { useParams, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import { motion, useReducedMotion } from 'motion/react';
import { useAuthSession } from '@/components/auth-session-provider';
import {
  apiDiagnosticOutroSeen,
  apiDiagnosticState,
  type DiagnosticState,
} from '@/lib/api';
import { getAccessToken } from '@/lib/auth-storage';
import {
  clearOutroBootstrap,
  readOutroBootstrap,
} from '@/lib/diagnostic-outro-bootstrap';
import { ProgressRail } from './ProgressRail';
import { PlayerStage } from './PlayerStage';
import {
  outroBodyVariants,
  outroStaggerContainer,
  outroStaggerItem,
} from './diagnostic-motion';

function hasOutroContent(state: DiagnosticState | null): boolean {
  return state?.nextStep.type === 'module_outro';
}

export function ModuleOutro() {
  const router = useRouter();
  const params = useParams<{ moduleSlug: string }>();
  const { status, refresh } = useAuthSession();
  const reduced = useReducedMotion();
  const [state, setState] = useState<DiagnosticState | null>(() => readOutroBootstrap());
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (status !== 'authenticated') return;
    const token = getAccessToken();
    if (!token) return;

    apiDiagnosticState(token)
      .then((s) => {
        setState(s);
        clearOutroBootstrap();
      })
      .catch(() => {});
  }, [status]);

  async function handleContinue() {
    const token = getAccessToken();
    if (!token || !params.moduleSlug) return;
    setLoading(true);
    setError(null);
    try {
      await apiDiagnosticOutroSeen(token, params.moduleSlug);
      const next = await apiDiagnosticState(token);
      if (next.nextStep.type === 'question' && next.sessionState.currentModuleSlug) {
        router.push(`/diagnostico/modulo/${next.sessionState.currentModuleSlug}/pregunta`);
      } else if (next.nextStep.type === 'diagnostic_complete') {
        await refresh({ force: true });
        router.push('/diagnostico/resultado');
      } else {
        throw new Error('unexpected_step');
      }
    } catch {
      setError('No pudimos continuar. Revisa tu conexión e intenta de nuevo.');
      setLoading(false);
    }
  }

  const outro =
    state?.nextStep.type === 'module_outro' ? state.nextStep.data : null;
  const ss = state?.sessionState;
  const showContent = hasOutroContent(state);

  return (
    <PlayerStage
      header={(
        <ProgressRail
          pct={ss?.completionPct ?? 0}
          moduleTitle={ss?.currentModuleTitle ?? outro?.titleEs}
          contextLabel="Auditoría inicial"
          variant="outro"
        />
      )}
      primary={{
        label: loading ? 'Cargando…' : 'Continuar',
        onClick: handleContinue,
        disabled: !showContent || loading,
      }}
    >
      {showContent ? (
        <motion.div
          className="dk-outro-body"
          variants={reduced ? undefined : outroBodyVariants}
          initial={reduced ? false : 'initial'}
          animate={reduced ? undefined : 'animate'}
        >
          <motion.div
            variants={reduced ? undefined : outroStaggerContainer}
            initial={reduced ? false : 'hidden'}
            animate={reduced ? undefined : 'show'}
          >
            <motion.p className="dk-outro-eyebrow" variants={reduced ? undefined : outroStaggerItem}>
              Módulo completo
            </motion.p>

            {outro ? (
              <>
                <motion.h2 className="dk-outro-title" variants={reduced ? undefined : outroStaggerItem}>
                  {outro.titleEs}
                </motion.h2>
                <motion.p className="dk-outro-text" variants={reduced ? undefined : outroStaggerItem}>
                  {outro.outroText}
                </motion.p>
                {outro.readings && outro.readings.length > 0 && (
                  <motion.dl className="dk-outro-readings" variants={reduced ? undefined : outroStaggerItem}>
                    {outro.readings.map((line) => (
                      <div key={line.label} className="dk-outro-reading">
                        <dt>{line.label}</dt>
                        <dd>{line.detail}</dd>
                      </div>
                    ))}
                  </motion.dl>
                )}
              </>
            ) : (
              <motion.h2 className="dk-outro-title" variants={reduced ? undefined : outroStaggerItem}>
                Módulo completado.
              </motion.h2>
            )}
            {error ? <p className="dk-player-error" role="alert">{error}</p> : null}
          </motion.div>
        </motion.div>
      ) : (
        <div className="dk-outro-body dk-outro-body--loading" aria-hidden>
          <div className="dk-outro-skeleton dk-outro-skeleton--title" />
          <div className="dk-outro-skeleton dk-outro-skeleton--text" />
          <div className="dk-outro-skeleton dk-outro-skeleton--metric" />
        </div>
      )}
    </PlayerStage>
  );
}
