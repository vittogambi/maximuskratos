/**
 * Anchors of a scale item. `stem` exists when the catalog carries the question with its anchors inline.
 * `points` holds the printed label of each point when the workbook gives one for every point.
 */
export type ScalePrompt = { stem?: string; low: string; high: string; points?: Partial<Record<number, string>> };

type CatalogPrompt = ScalePrompt & { stem: string };

/** Presentation of concatenated scale prompts. Keyed by sourceRef. Words are exact catalog slices. */
export const SCALE_PROMPTS: Record<string, CatalogPrompt> = {
  "lucas-v1:E-AUD-001!R6": { stem: "¿Mis decisiones diarias reflejan al hombre que digo que quiero llegar a ser?", low: "Casi nunca; la mayoría de mis decisiones contradicen lo que digo querer.", high: "Casi siempre; mis decisiones reflejan claramente al hombre que quiero ser." },
  "lucas-v1:E-AUD-001!R7": { stem: "Cuando siento presión o una emoción intensa, ¿puedo reconocer lo que siento y elegir una respuesta coherente con mis principios?", low: "La emoción suele gobernar mis decisiones.", high: "Reconozco la emoción, comprendo su mensaje y respondo deliberadamente." },
  "lucas-v1:E-AUD-001!R8": { stem: "¿Qué tan seguido uso excusas que suenan razonables, pero no lo son?", low: "Uso excusas con frecuencia y las justifico fácilmente.", high: "Rara vez uso excusas; asumo responsabilidad directa." },
  "lucas-v1:E-AUD-001!R9": { stem: "¿Confío en mí mismo para terminar lo que empiezo?", low: "No confío; suelo abandonar lo que inicio.", high: "Confío plenamente; soy consistente y confiable conmigo mismo." },
  "lucas-v1:E-AUD-001!R10": { stem: "¿Qué historia me cuento a mí mismo cuando las cosas se ponen difíciles?", low: "Una historia de víctima o resignación.", high: "Una historia de responsabilidad, crecimiento y dominio personal." },
  "lucas-v1:E-AUD-001!R16": { stem: "¿Qué tan seguido realiza entrenamiento físico?", low: "No entreno", high: "5 ó más días a la semana" },
  "lucas-v1:E-AUD-001!R17": { stem: "¿Qué tan constante he sido con la alimentación — no perfecto, sino honesto?", low: "Muy desordenado; sin estructura ni control.", high: "Muy consistente; alimentación alineada al objetivo." },
  "lucas-v1:E-AUD-001!R18": { stem: "¿Mi calidad de sueño está apoyando mi progreso o lo está saboteando silenciosamente?", low: "Sabotea claramente mi progreso.", high: "Apoya plenamente mi progreso y rendimiento." },
  "lucas-v1:E-AUD-001!R19": { stem: "¿Con qué frecuencia utilizo comida, alcohol, sexo, compras, pantallas o entretenimiento para evitar emociones, conversaciones o responsabilidades que debería enfrentar?", low: "Muy frecuentemente.", high: "Casi nunca; puedo reconocer y procesar lo que siento." },
  "lucas-v1:E-AUD-001!R20": { stem: "¿Sus hábitos le están haciendo avanzar con claridad o drenando su energía?", low: "La mayoría de mis hábitos drenan energía.", high: "Mis hábitos están claramente alineados con avanzar." },
  "lucas-v1:E-AUD-001!R26": { stem: "¿Planifico mi semana o, en su mayoría, solo reacciono a ella?", low: "Solo reacciono; no planifico.", high: "Planifico con claridad y propósito" },
  "lucas-v1:E-AUD-001!R27": { stem: "¿Mi entorno está configurado para apoyar la disciplina o la comodidad?", low: "Favorece claramente la comodidad.", high: "Diseñado intencionalmente para la disciplina." },
  "lucas-v1:E-AUD-001!R28": { stem: "¿Quiénes están a mi alrededor elevan mis estándares o los bajan silenciosamente?", low: "Mi entorno baja claramente mis estándares.", high: "Estoy rodeado de personas que elevan mis estándares." },
  "lucas-v1:E-AUD-001!R29": { stem: "Cuando me desvío del rumbo, ¿qué tan rápido corrijo el curso?", low: "No corrijo; sigo desviándome.", high: "Corrijo casi de inmediato." },
  "lucas-v1:E-AUD-001!R30": { stem: "Si siguiera viviendo exactamente de esta manera durante un año más, ¿me sentiría orgulloso del lugar al que me lleva?", low: "No; me decepcionaría profundamente.", high: "Muy orgulloso; este camino refleja quién quiero ser." },
  "lucas-v1:E-AUD-001!R39": { stem: "Planificación Financiera: ¿Cuentas con un presupuesto escrito o un plan estructurado para tus finanzas a corto y largo plazo?", low: "Cero planificación", high: "Plan financiero profesional y seguimiento semanal)." },
  "lucas-v1:E-AUD-001!R46": { stem: "Dinámica de Pareja: ¿Qué tan sólida, alineada y nutritiva es tu relación de pareja actual (o tu preparación para tener una)?", low: "Conflicto constante/Tóxica", high: "Alineación total en valores y apoyo mutuo" },
  "lucas-v1:E-AUD-001!R47": { stem: "Relación Familiar (Padres/Hijos): ¿Qué tan sano es el vínculo con tu núcleo familiar y qué tan presente estás en su desarrollo?", low: "Distante/Conflictivo", high: "Presencia activa, respeto y armonía" },
  "lucas-v1:E-AUD-001!R48": { stem: "Círculo de Influencia (Amistades): ¿Qué tanto te impulsan tus relaciones sociales y amigos hacia la excelencia y el sentido de propósito?", low: "Amigos que me restan/vicio", high: "Círculo de hierro que me exige y apoya" },
  "lucas-v1:E-AUD-001!R49": { stem: "Entorno Laboral/Social: ¿Qué tan respetado y funcional es tu liderazgo en tu entorno de trabajo o comunidad?", low: "Invisible o en conflicto", high: "Referente de orden y liderazgo." },
};

/**
 * Only the printed endpoints of the Big Five items. Source: `260529-FORMULARIOS-X-PASO.xlsx`, sheet E-PER-000,
 * column C (Observación), rows 187 to 205. The catalog v6 dropped them (its `contextEs` holds the block title).
 * Points 2 to 4 have no text in the source, so they get none here. Closing period removed, as in the other labels.
 */
export const WORKBOOK_ENDPOINTS: Record<string, ScalePrompt> = {
  "lucas-v1:E-PER-000!R187": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C187
  "lucas-v1:E-PER-000!R188": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C188
  "lucas-v1:E-PER-000!R189": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C189
  "lucas-v1:E-PER-000!R191": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C191
  "lucas-v1:E-PER-000!R192": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C192
  "lucas-v1:E-PER-000!R193": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C193
  "lucas-v1:E-PER-000!R195": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C195
  "lucas-v1:E-PER-000!R196": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C196
  "lucas-v1:E-PER-000!R197": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C197
  "lucas-v1:E-PER-000!R199": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C199
  "lucas-v1:E-PER-000!R200": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C200
  "lucas-v1:E-PER-000!R201": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C201
  "lucas-v1:E-PER-000!R203": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C203
  "lucas-v1:E-PER-000!R204": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C204
  "lucas-v1:E-PER-000!R205": { low: "Totalmente en desacuerdo", high: "Totalmente de acuerdo" }, // C205
};

const FREQUENCY_POINTS: Record<number, string> = {
  1: "Nunca ocurre",
  2: "Rara vez ocurre",
  3: "Ocurre a veces",
  4: "Ocurre frecuentemente",
  5: "Ocurre siempre",
};

/**
 * F-RAD-002 items whose workbook legend (column C) is a frequency scale. Catalog v6 applies the agreement set to the
 * whole family (`scripts/formulario/build_formulario_next.mjs`, AGREE). Source: `260529-FORMULARIOS-X-PASO.xlsx`,
 * sheet F-RAD-002, cells C6, C8, C17, C25, C26, C27. Only the shown text changes: the catalog and the option ids stay.
 */
export const WORKBOOK_POINT_LABELS: Record<string, ScalePrompt> = {
  "lucas-v1:F-RAD-002!R6": { low: FREQUENCY_POINTS[1], high: FREQUENCY_POINTS[5], points: FREQUENCY_POINTS },
  "lucas-v1:F-RAD-002!R8": { low: FREQUENCY_POINTS[1], high: FREQUENCY_POINTS[5], points: FREQUENCY_POINTS },
  "lucas-v1:F-RAD-002!R17": { low: FREQUENCY_POINTS[1], high: FREQUENCY_POINTS[5], points: FREQUENCY_POINTS },
  "lucas-v1:F-RAD-002!R25": { low: FREQUENCY_POINTS[1], high: FREQUENCY_POINTS[5], points: FREQUENCY_POINTS },
  "lucas-v1:F-RAD-002!R26": { low: FREQUENCY_POINTS[1], high: FREQUENCY_POINTS[5], points: FREQUENCY_POINTS },
  "lucas-v1:F-RAD-002!R27": { low: FREQUENCY_POINTS[1], high: FREQUENCY_POINTS[5], points: FREQUENCY_POINTS },
};

export function scalePromptFor(sourceRef: string | null | undefined): ScalePrompt | null {
  if (!sourceRef) return null;
  return SCALE_PROMPTS[sourceRef] ?? WORKBOOK_ENDPOINTS[sourceRef] ?? WORKBOOK_POINT_LABELS[sourceRef] ?? null;
}
